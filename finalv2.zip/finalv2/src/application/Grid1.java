package application;

import java.io.IOException;



import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;


public class Grid1 extends Application {
	static Stage yo = new Stage(); 
	static Scene yooo;
	/* (non-Javadoc)
	 * @see javafx.application.Application#start(javafx.stage.Stage)
	 */
	@Override
	/*
	 * (non-Javadoc)
	 * @see javafx.application.Application#start(javafx.stage.Stage)
	 * start method for loading grid 1 i.e. the grid from the main page
	 */
	public void start(Stage prStage) throws IOException
	{
		Parent loader =FXMLLoader.load(getClass().getResource("/application/Grid1.fxml"));
		Scene scene=new Scene(loader);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		prStage.setScene(scene);
		prStage.sizeToScene();
        prStage.show();
        yo=prStage;
        Scene x = scene;
	}
	/**
	 * @return Stage
	 */
	public static Stage getstageee()
	{
		return yo;
	}
	/**
	 * 
	 * @return Scene
	 */
	public static Scene getscene()
	{
		return yooo;
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}




