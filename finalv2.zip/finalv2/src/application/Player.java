package application;

import java.io.Serializable;

import javafx.scene.paint.Color;

public class Player implements Serializable
{
	String name;
	
	/**
	 * color stored as a string in player class attribute
	 */
	String color;
	int count;
	/**
	 * @param colorr
	 * Converts colour to string and returns the value
	 * @return String
	 */
	public String getcolorasstring(Color colorr) {
		
		color=colorr.toString();
		return colorr.toString();
	}
	/**
	 *
	 * @return String(name attribute)
	 */
	public String getnamefromplayerlist() {
		
		return name;
	}
	/**
	 * constructor for player class which has color and name attribute
	 */
	public Player() {
		
		this.color=color;
		this.name=name;
	}
	
	/**takes color c and returns its value
	 * @return Color
	 */
	public Color getcolor() {
		
		Color c=Color.valueOf(color);
		return c;
	}
	
	/**takes c and converts it to string and stores it in String color
	 * @param c (color c )
	 */
	public void setcolor(Color c) {
		
		color=c.toString();
	}
}
