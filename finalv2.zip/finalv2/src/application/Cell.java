package application;

import java.io.Serializable;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 * @author snehasi
 * Cell class implements serializable, has the attributes for Group, critical mass, count, Player,r,c,x,y
 *
 */
public class Cell implements Serializable 
{
	Group g;
	int cmass;
	int count; //
	Player player; //
	int r; 
	int c; 
	int x;
	int y;
	
	/*
	 * Color as a string as color is non serializable
	 */
	String color; 
	int explode; 
	/**
	 * critical mass of cells i.e. the number of spheres when a cell will explode
	 * @return int
	 */
	public int get_Cmass(int n,int m)
	{
		if((r==0 || r==n-1 ) && (c==0 || c==m-1))
		{
			return 2;
		}
		else if(r==0 || r==n-1 || c==0 || c==m-1)
		{
			return 3;
		}
		else
		{
			return 4;
		}
	}
	
	public int getcount() {
		return count;
	}
	
	public String getcolorasstring() {
		return color.toString();
	}
	
	/**
	 * converts the string color into a Color and returns it
	 * @return Color
	 */
	public Color getcolor() {
		Color c=Color.valueOf(color);
		return c;
	}
	
	/**
	 * takes a color as input and sets it to a string value
	 * @param c
	 */
	public void setcolor(Color c) {
		color=c.toString();
	}
}
