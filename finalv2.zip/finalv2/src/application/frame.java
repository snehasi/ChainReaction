package application;

import java.io.Serializable;


public class frame implements Serializable{
	Player player;
	int i;
	int j;
	int q;
	
	/**
	 * @return Player getters and setters for the class attributes implemented 
	 */
	public Player getplayer() {
	
		return player;
	}
	/**
	 * @return Integer
	 */
	public int getq() {		
		return q;
	}
	/**
	 * @return Integer
	 */
	public int geti() {
		return i;
	}
	/**
	 * @return Integer
	 */
	public int getj() {
		return j;
	}
	public void setplayer(Player p) {
		player=p;
	}
	public void setq(int q1) {
		q=q1;
	}
	public void seti(int i1) {
		i=i1;
	}
	public void setj(int j1) {
		j=j1;
	}
}
